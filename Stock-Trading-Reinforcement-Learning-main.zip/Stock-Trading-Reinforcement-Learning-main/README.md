# Stock-Trading-Reinforcement-Learning
Deep Reinforcement Learning Project based on this paper -> https://ieeexplore.ieee.org/document/8521585

Both .ipynb files in this directory are for <strong>Apple</strong> and <strong>Amazon</strong> stocks.
